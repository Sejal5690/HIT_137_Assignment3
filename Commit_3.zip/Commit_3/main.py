# Main file for Assignment 3 - With GUI Implementation

import sys
from pathlib import Path

# Add the project root to Python path for imports
project_root = Path(__file__).parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

def check_basic_dependencies():
    """Check if basic dependencies are available."""
    try:
        import tkinter
        from PIL import Image
        import torch
        import transformers
        import diffusers
        return True
    except ImportError as e:
        print(f"Missing basic dependency: {e}")
        print("Please install required packages:")
        print("pip install transformers diffusers torch Pillow")
        return False

def test_gui():
    """Test the GUI components."""
    try:
        from gui.main_window import MainWindow
        from gui.widgets import ImageDisplayFrame, StatusBar
        from gui.decorators import validate_input, log_operation
        
        print("✓ All GUI components imported successfully")
        return True
    except Exception as e:
        print(f"GUI test failed: {e}")
        return False

def main():
    # GUI application
    print("=" * 60)
    print("AI Model Demo Application - HIT137 Assignment 3")
    print("GUI Framework Implementation Complete")
    print("=" * 60)
    
    if not check_basic_dependencies():
        print("Please install dependencies first.")
        sys.exit(1)
    
    if not test_gui():
        print("GUI setup failed.")
        sys.exit(1)
    
    print("Starting GUI application...")
    
    try:
        from gui.main_window import MainWindow
        app = MainWindow()
        app.mainloop()
        print("Application closed successfully")
        
    except Exception as e:
        print(f"Failed to start GUI: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()